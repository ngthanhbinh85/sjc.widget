#!/bin/bash

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PY_SCRIPT="$SCRIPT_DIR/sjc_price.py"
CACHE_FILE="$SCRIPT_DIR/python_path_cache"

# Python đã tìm được từ lần trước.
if [ -f "$CACHE_FILE" ]; then
  CACHED_PYTHON="$(cat "$CACHE_FILE")"

  if [ -x "$CACHED_PYTHON" ]; then
    exec "$CACHED_PYTHON" "$PY_SCRIPT"
  fi

  rm -f "$CACHE_FILE"
fi

FOUND_PYTHON=""

CANDIDATES=(
  "$(command -v python3 2>/dev/null)"
  "/opt/homebrew/bin/python3"
  "/usr/local/bin/python3"
  /Library/Frameworks/Python.framework/Versions/*/bin/python3
)

for PYTHON in "${CANDIDATES[@]}"; do
  [ -n "$PYTHON" ] || continue
  [ -x "$PYTHON" ] || continue

  if [ -z "$FOUND_PYTHON" ]; then
    FOUND_PYTHON="$PYTHON"
  fi

  if "$PYTHON" -c "import curl_cffi" >/dev/null 2>&1; then
    printf '%s\n' "$PYTHON" > "$CACHE_FILE"

    exec "$PYTHON" "$PY_SCRIPT"
  fi
done

if [ -n "$FOUND_PYTHON" ]; then
  printf '{"error":"Đã tìm thấy Python nhưng chưa cài curl_cffi. Chạy: %s -m pip install --upgrade curl_cffi"}\n' "$FOUND_PYTHON"
else
  printf '{"error":"Không tìm thấy Python 3. Vui lòng cài Python 3 trước khi sử dụng widget."}\n'
fi

exit 1